import pyrebase
from pprint import pprint 
from operator import itemgetter
import time
import requests
import json
import serial
config = {
 "apiKey": " AIzaSyCewY94iDXoK0TB5SOkYo3tUTYH9SGHdus ",
  "authDomain": "movie-recommendation-sys-c4fe2.firebaseio.com",
  "databaseURL": "https://movie-recommendation-sys-c4fe2.firebaseio.com/",
  "storageBucket": "movie-recommendation-sys-c4fe2.appspot.com"
}

firebase = pyrebase.initialize_app(config)

db = firebase.database()
res = db.child("Admin").get().val()
g = input("Genre: ")

results =[]
result2 = []
for x in res.items():
	if(x[1]["genre"]==g):
		results.append((x[1]['movie'],x[1]["score"]))
		
x = sorted(results,key=itemgetter(1))
for y in res.items():
	if(y[1]["genre"]==g):
		result2.append((y[1]['movie'],y[1]["rating"]))
		
y = sorted(result2,key=itemgetter(1))
b = list(x)
b.reverse()

a = list(y)
a.reverse()


pprint('Movie according to the best Ratings:')
pprint(a)
print("\n")
pprint('Movie according to Sentiment Analysis Score:')
pprint(b)
#pprint(x)
#pprint(res.items()[0][1]["genre"])
#pprint(y)
#pprint(res.items()[0][1]["rating"])
